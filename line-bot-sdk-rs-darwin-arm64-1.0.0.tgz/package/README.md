# `line-bot-sdk-rs-darwin-arm64`

This is the **aarch64-apple-darwin** binary for `line-bot-sdk-rs`
