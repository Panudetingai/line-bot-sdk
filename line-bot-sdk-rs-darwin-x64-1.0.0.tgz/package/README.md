# `line-bot-sdk-rs-darwin-x64`

This is the **x86_64-apple-darwin** binary for `line-bot-sdk-rs`
